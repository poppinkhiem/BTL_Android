package com.subi.quanlysinhvien;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.subi.quanlysinhvien.adapter.LopAdapter;
import com.subi.quanlysinhvien.adapter.SVLopAdapter;
import com.subi.quanlysinhvien.add.AddLop;
import com.subi.quanlysinhvien.add.AddSVLop;
import com.subi.quanlysinhvien.database.DaoMaLop;
import com.subi.quanlysinhvien.database.DaoSVLop;
import com.subi.quanlysinhvien.model.Lop;
import com.subi.quanlysinhvien.model.SinhVien_Lop;

import java.util.ArrayList;

public class SVLopActivity extends AppCompatActivity {
    ArrayList<SinhVien_Lop> listLop = new ArrayList<>();
    ListView listView;
    SVLopAdapter adapter;
    DaoSVLop daoLop;
    FloatingActionButton flAdd;
    Button all, lke;
    Lop lop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_svlop);
         lop =(Lop) getIntent().getSerializableExtra("lop");
        TextView textView = findViewById(R.id.DanhSach);
        try {
            textView.setText("Danh sách lớp "+lop.getTenLop());
        }
        catch (Exception e){

        }
        all =  findViewById(R.id.btn_all);
        lke  =findViewById(R.id.btn_lke);
        listView = findViewById(R.id.lvList);
        flAdd = findViewById(R.id.flFloat);
        daoLop = new DaoSVLop(this);
        listLop = daoLop.getAll(lop.getMaLop());
        adapter = new SVLopAdapter(this, listLop);
        listView.setAdapter(adapter);
        //Thống kê
        TextView text = findViewById(R.id.tv_sum);
        text.setText("Tổng sinh viên: "+listLop.size());

        flAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SVLopActivity.this, AddSVLop.class);
                i.putExtra("maLop", lop.getMaLop());
                startActivity(i);
            }
        });

        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listLop.clear();
                listLop.addAll(daoLop.getAll(lop.getMaLop()));
                adapter.notifyDataSetChanged();
            }
        });

        lke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listLop.clear();
                listLop.addAll(daoLop.getAllStt(lop.getMaLop()));
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        listLop.clear();
        listLop.addAll(daoLop.getAll(lop.getMaLop()));
        adapter.notifyDataSetChanged(); }
}