package com.subi.quanlysinhvien.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.subi.quanlysinhvien.model.Lop;
import java.util.ArrayList;

public class DaoMaLop {
    Database dtbLop;

    public DaoMaLop(Context context) {
        dtbLop = new Database(context);
    }

    public ArrayList<Lop> getAll() {
        ArrayList<Lop> list = new ArrayList<>();
        SQLiteDatabase db = dtbLop.getReadableDatabase();
        Cursor cs = db.rawQuery("SELECT * FROM Lop", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()) {
            int maLop = cs.getInt(0);
            String tenLop = cs.getString(1);
            String moTa = cs.getString(2);
            Lop lop = new Lop(maLop, tenLop, moTa);
            list.add(lop);
            cs.moveToNext();
        }
        cs.close();
        return list;
    }

    //Thêm lớp mới
    public boolean them(Lop lop) {
        SQLiteDatabase db = dtbLop.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tenLop", lop.getTenLop());
        contentValues.put("moTa", lop.getMoTa());
        long r = db.insert("Lop", null, contentValues);
        if (r <= 0) {
            return false;
        }
        return true;
    }

    //Cập nhật tên Lớp mới, không cho sửa mã lớp bởi mã lớp là khóa chính, sửa sẽ lỗi!
    public boolean sua(Lop lop) {
        SQLiteDatabase db = dtbLop.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tenLop", lop.getTenLop());
        contentValues.put("moTa", lop.getMoTa());
        int r = db.update("Lop", contentValues, "maLop=?", new String[]{lop.getMaLop() + ""});
        if (r <= 0) {
            return false;
        }
        return true;
    }

    //Xóa lớp
    public boolean xoa(Lop lop) {
        SQLiteDatabase db = dtbLop.getWritableDatabase();
        int r = db.delete("Lop", "maLop=?", new String[]{lop.getMaLop() + ""});
        if (r <= 0) {
            return false;
        }
        return true;
    }
}
