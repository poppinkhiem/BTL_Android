package com.subi.quanlysinhvien.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.subi.quanlysinhvien.R;
import com.subi.quanlysinhvien.database.DaoSinhVien;
import com.subi.quanlysinhvien.model.SinhVien;

import java.util.ArrayList;

public class SVAdapter extends BaseAdapter {
    Context context;
    ArrayList<SinhVien> listSv = new ArrayList<>();
    DaoSinhVien daoSV;

    public SVAdapter(Context context, ArrayList<SinhVien> listSv) {
        this.context = context;
        this.listSv = listSv;
    }

    @Override
    public int getCount() {
        return listSv.size();
    }

    @Override
    public Object getItem(int position) {
        return listSv.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        final SinhVien sv = listSv.get(position);
        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            convertView = inflater.inflate(R.layout.one_sinhvien, null);
            holder.ma = convertView.findViewById(R.id.ma);
            holder.maSv = convertView.findViewById(R.id.tvMaSV);
            holder.ten = convertView.findViewById(R.id.ten);
            holder.tenSv = convertView.findViewById(R.id.tvTenSV);
            holder.nganh = convertView.findViewById(R.id.nganh);
            holder.nganhSv = convertView.findViewById(R.id.tvNganh);
            holder.lop = convertView.findViewById(R.id.lop);
            holder.lopSv = convertView.findViewById(R.id.tvmaLop);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        daoSV = new DaoSinhVien(context);
        holder.maSv.setText(sv.getTenSV());
        holder.tenSv.setText(sv.getNamsinh());
        holder.nganhSv.setText(sv.getQuequan());
        holder.lopSv.setText(sv.getNamhoc());
        return convertView;
    }

    class ViewHolder {
        TextView ma, ten, nganh, lop, maSv, tenSv, nganhSv, lopSv;
    }
}
