package com.subi.quanlysinhvien;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.subi.quanlysinhvien.adapter.SVAdapter;
import com.subi.quanlysinhvien.add.AddSV;
import com.subi.quanlysinhvien.database.DaoSinhVien;
import com.subi.quanlysinhvien.model.SinhVien;

import java.util.ArrayList;

public class SVActivity extends AppCompatActivity {
    ArrayList<SinhVien> svList = new ArrayList<>();
    ListView lvSv;
    FloatingActionButton flFloat;
    SVAdapter svAdapter;
    DaoSinhVien daoSv;
    Button all, lke;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_svactivity);

        lvSv = findViewById(R.id.lvList);
        flFloat = findViewById(R.id.flFloat);
        daoSv = new DaoSinhVien(this);
        all =  findViewById(R.id.btn_all);
        lke  =findViewById(R.id.btn_lke);
        svList = daoSv.getAll();
        svAdapter = new SVAdapter(this, svList);
        lvSv.setAdapter(svAdapter);

        flFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SVActivity.this, AddSV.class);
                startActivity(i);
                finish();
            }
        });

        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                svList.clear();
                svList.addAll(daoSv.getAll());
                svAdapter.notifyDataSetChanged();
            }
        });

        lke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                svList.clear();
                svList.addAll(daoSv.getAllByNameAndNamHoc("nam", 2));
                svAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}