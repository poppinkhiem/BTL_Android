package com.subi.quanlysinhvien;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.subi.quanlysinhvien.adapter.LopAdapter;
import com.subi.quanlysinhvien.add.AddLop;
import com.subi.quanlysinhvien.database.DaoMaLop;
import com.subi.quanlysinhvien.model.Lop;

import java.util.ArrayList;

public class LopActivity extends AppCompatActivity {
    ArrayList<Lop> listLop = new ArrayList<>();
    ListView listView;
    LopAdapter adapter;
    DaoMaLop daoLop;
    FloatingActionButton flAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lop);
        listView = findViewById(R.id.lvList);
        flAdd = findViewById(R.id.flFloat);
        daoLop = new DaoMaLop(this);
        listLop = daoLop.getAll();
        adapter = new LopAdapter(this, listLop);
        listView.setAdapter(adapter);


        flAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LopActivity.this, AddLop.class);
                startActivity(i);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Lop lop = listLop.get(position);
            Intent intent = new Intent(LopActivity.this, SVLopActivity.class);
            intent.putExtra("lop", lop);
            startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}