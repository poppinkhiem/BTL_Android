package com.subi.quanlysinhvien.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.subi.quanlysinhvien.model.SinhVien_Lop;

import java.util.ArrayList;

public class DaoSVLop {
    Database dtbSinhVien_Lop;

    public DaoSVLop(Context context) {
        dtbSinhVien_Lop = new Database(context);
    }

    public ArrayList<SinhVien_Lop> getAll(int maLopSv) {
        ArrayList<SinhVien_Lop> list = new ArrayList<>();
        SQLiteDatabase db = dtbSinhVien_Lop.getReadableDatabase();
        Cursor cs = db.rawQuery("SELECT * FROM SinhVien_Lop where maLop="+maLopSv, null);
        cs.moveToFirst();
        while (!cs.isAfterLast()) {
            int maLop = cs.getInt(1);
            int maSV = cs.getInt(2);
            String kyhoc = cs.getString(3);
            String sotinchi = cs.getString(4);
            SinhVien_Lop lop = new SinhVien_Lop(maLop, maSV, kyhoc, sotinchi);
            list.add(lop);
            cs.moveToNext();
        }
        cs.close();
        return list;
    }

    public ArrayList<SinhVien_Lop> getAllStt(int maLopSv) {
        ArrayList<SinhVien_Lop> list = new ArrayList<>();
        SQLiteDatabase db = dtbSinhVien_Lop.getReadableDatabase();
        Cursor cs = db.rawQuery("SELECT * FROM SinhVien_Lop where maLop="+maLopSv+" ORDER  BY maSV", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()) {
            int maLop = cs.getInt(1);
            int maSV = cs.getInt(2);
            String kyhoc = cs.getString(3);
            String sotinchi = cs.getString(4);
            SinhVien_Lop lop = new SinhVien_Lop(maLop, maSV, kyhoc, sotinchi);
            list.add(lop);
            cs.moveToNext();
        }
        cs.close();
        return list;
    }

    //Thêm lớp mới
    public boolean them(SinhVien_Lop lop) {
        SQLiteDatabase db = dtbSinhVien_Lop.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("maLop", lop.getMaLop());
        contentValues.put("maSV", lop.getMaSV());
        contentValues.put("kyhoc", lop.getKyhoc());
        contentValues.put("sotinchi", lop.getSotinchi());
        long r = db.insert("SinhVien_Lop", null, contentValues);
        if (r <= 0) {
            return false;
        }
        return true;
    }

    //Xóa lớp
//    public boolean xoa(SinhVien_Lop lop) {
//        SQLiteDatabase db = dtbSinhVien_Lop.getWritableDatabase();
//        int r = db.delete("SinhVien_Lop", "maLop=?", new String[]{lop.getMaLop()+""});
//        if (r <= 0) {
//            return false;
//        }
//        return true;
//    }
}
