package com.subi.quanlysinhvien.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.subi.quanlysinhvien.R;
import com.subi.quanlysinhvien.database.DaoMaLop;
import com.subi.quanlysinhvien.model.Lop;

import java.util.ArrayList;

public class LopAdapter extends BaseAdapter {
    Context context;
    ArrayList<Lop> listLop;
    DaoMaLop daoLop;

    public LopAdapter(Context context, ArrayList<Lop> listLop) {
        this.context = context;
        this.listLop = listLop;

    }

    @Override
    public int getCount() {
        return listLop.size();
    }

    @Override
    public Object getItem(int position) {
        return listLop.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final Lop lop = listLop.get(position);


        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            convertView = inflater.inflate(R.layout.one_dslop, null);
            holder.txtMaLop = convertView.findViewById(R.id.tvMaLopx);
            holder.txtTenLop = convertView.findViewById(R.id.tvTenLop);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        daoLop = new DaoMaLop(context);

        holder.txtMaLop.setText(lop.getTenLop());
        holder.txtTenLop.setText(lop.getMoTa());
        return convertView;


    }


    class ViewHolder {
        TextView txtMaLop, txtTenLop;
    }


}
