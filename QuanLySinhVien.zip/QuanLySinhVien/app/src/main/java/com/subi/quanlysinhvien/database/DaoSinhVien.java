package com.subi.quanlysinhvien.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.subi.quanlysinhvien.model.SinhVien;

import java.util.ArrayList;

public class DaoSinhVien {
    Database dtbSV;

    public DaoSinhVien(Context context) {
        dtbSV = new Database(context);
    }

    public ArrayList<SinhVien> getAll() {
        ArrayList<SinhVien> list = new ArrayList<>();
        SQLiteDatabase dtbSv = dtbSV.getReadableDatabase();
        Cursor cs = dtbSv.rawQuery("SELECT * FROM sinhVien", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()) {
            int maSv = cs.getInt(0);
            String tenSv = cs.getString(1);
            String namsinh = cs.getString(2);
            String quequan = cs.getString(3);
            String namhoc = cs.getString(4);

            SinhVien sv = new SinhVien(maSv, tenSv, namsinh, quequan, namhoc);
            list.add(sv);
            cs.moveToNext();
        }
        cs.close();
        return list;
    }

    public ArrayList<SinhVien> getAllByNameAndNamHoc(String name, int nam) {
        ArrayList<SinhVien> list = new ArrayList<>();
        SQLiteDatabase dtbSv = dtbSV.getReadableDatabase();
        Cursor cs = dtbSv.rawQuery("SELECT * FROM sinhVien where tenSV='"+name+"' and namhoc='"+nam+"'", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()) {
            int maSv = cs.getInt(0);
            String tenSv = cs.getString(1);
            String namsinh = cs.getString(2);
            String quequan = cs.getString(3);
            String namhoc = cs.getString(4);

            SinhVien sv = new SinhVien(maSv, tenSv, namsinh, quequan, namhoc);
            list.add(sv);
            cs.moveToNext();
        }
        cs.close();
        return list;
    }

    //Thêm lớp mới
    public boolean them(SinhVien sv) {
        SQLiteDatabase db = dtbSV.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tenSV", sv.getTenSV());
        contentValues.put("namsinh", sv.getNamsinh());
        contentValues.put("quequan", sv.getQuequan());
        contentValues.put("namhoc", sv.getNamhoc());
        long r = db.insert("sinhVien", null, contentValues);
        if (r <= 0) {
            return false;
        }
        return true;
    }

    //Cập nhật tên Lớp mới, không cho sửa mã sinh viên bởi mã lớp là khóa chính, sửa sẽ lỗi!
    public boolean sua(SinhVien sv) {
        SQLiteDatabase db = dtbSV.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tenSV", sv.getTenSV());
        contentValues.put("namsinh", sv.getNamsinh());
        contentValues.put("quequan", sv.getQuequan());
        contentValues.put("namhoc", sv.getNamhoc());
        int r = db.update("sinhVien", contentValues, "maSV=?", new String[]{String.valueOf(sv.getMaSV())});
        if (r <= 0) {
            return false;
        }
        return true;
    }
}
