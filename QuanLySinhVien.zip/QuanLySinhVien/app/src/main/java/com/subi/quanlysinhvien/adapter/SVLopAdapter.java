package com.subi.quanlysinhvien.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.subi.quanlysinhvien.R;
import com.subi.quanlysinhvien.database.DaoSVLop;
import com.subi.quanlysinhvien.model.Lop;
import com.subi.quanlysinhvien.model.SinhVien_Lop;

import java.util.ArrayList;

public class SVLopAdapter extends BaseAdapter {
    Context context;
    ArrayList<SinhVien_Lop> listSv = new ArrayList<>();
    DaoSVLop daoSV;

    public SVLopAdapter(Context context, ArrayList<SinhVien_Lop> listSv) {
        this.context = context;
        this.listSv = listSv;
    }

    @Override
    public int getCount() {
        return listSv.size();
    }

    @Override
    public Object getItem(int position) {
        return listSv.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        final SinhVien_Lop sv = listSv.get(position);
        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            convertView = inflater.inflate(R.layout.one_svlop, null);
            holder.maSv = convertView.findViewById(R.id.tvMaSV);
            holder.tenSv = convertView.findViewById(R.id.tvTenSV);
            holder.nganhSv = convertView.findViewById(R.id.tvNganh);
            holder.lopSv = convertView.findViewById(R.id.tvmaLop);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        daoSV = new DaoSVLop(context);
        holder.maSv.setText(sv.getMaLop()+"");
        holder.tenSv.setText(sv.getMaSV()+"");
        holder.nganhSv.setText(sv.getKyhoc()+"");
        holder.lopSv.setText(sv.getSotinchi()+"");
        return convertView;
    }

    class ViewHolder {
        TextView maSv, tenSv, nganhSv, lopSv;
    }
}
