package com.subi.quanlysinhvien.model;

public class SinhVien_Lop {
    private int maLop;
    private int maSV;
    private String kyhoc;
    private String sotinchi;

    public SinhVien_Lop() {
    }

    public SinhVien_Lop(int maLop, int maSV, String kyhoc, String sotinchi) {
        this.maLop = maLop;
        this.maSV = maSV;
        this.kyhoc = kyhoc;
        this.sotinchi = sotinchi;
    }

    public int getMaLop() {
        return maLop;
    }

    public void setMaLop(int maLop) {
        this.maLop = maLop;
    }

    public int getMaSV() {
        return maSV;
    }

    public void setMaSV(int maSV) {
        this.maSV = maSV;
    }

    public String getKyhoc() {
        return kyhoc;
    }

    public void setKyhoc(String kyhoc) {
        this.kyhoc = kyhoc;
    }

    public String getSotinchi() {
        return sotinchi;
    }

    public void setSotinchi(String sotinchi) {
        this.sotinchi = sotinchi;
    }
}
