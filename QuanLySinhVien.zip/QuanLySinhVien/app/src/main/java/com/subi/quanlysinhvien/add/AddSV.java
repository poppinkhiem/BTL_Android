package com.subi.quanlysinhvien.add;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.subi.quanlysinhvien.LopActivity;
import com.subi.quanlysinhvien.R;
import com.subi.quanlysinhvien.SVActivity;
import com.subi.quanlysinhvien.database.DaoSinhVien;
import com.subi.quanlysinhvien.model.SinhVien;

import java.util.ArrayList;

public class AddSV extends AppCompatActivity {
    TextView edtMa, edtTen, edtNganh, edtMaLop;
    Button btThemSV;
    DaoSinhVien daoSv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sv);
        edtMa = findViewById(R.id.edtAddMaSV);
        edtTen = findViewById(R.id.edtAddTenSV);
        edtNganh = findViewById(R.id.edtAddNganh);
        edtMaLop = findViewById(R.id.edtAddMaLopSV);
        btThemSV = findViewById(R.id.btnthemSV);

        btThemSV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                daoSv = new DaoSinhVien(AddSV.this);
                ArrayList<SinhVien> listSv = new ArrayList<>();
                String ten = edtMa.getText().toString().toLowerCase();
                String namsinh = edtTen.getText().toString();
                String quequan = edtNganh.getText().toString();
                String namhoc = edtMaLop.getText().toString();

                if (ten.isEmpty() || namsinh.isEmpty() || quequan.isEmpty() || namhoc.isEmpty()) {
                    Toast.makeText(AddSV.this, "Các trường không được để trống!", Toast.LENGTH_SHORT).show();
                } else {
                    SinhVien dsSv = new SinhVien(0, ten, namsinh, quequan, namhoc);
                    if (daoSv.them(dsSv)) {
                        startActivity(new Intent(AddSV.this, SVActivity.class));
                        finish();
                    } else {
                        Toast.makeText(AddSV.this, "Thêm lớp thất bại!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
