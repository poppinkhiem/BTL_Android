package com.subi.quanlysinhvien.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    public Database(Context context) {
        super(context, "DATABASE", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Tạo bảng mã lớp
        String sql = "CREATE TABLE Lop(" +
                "maLop integer primary key autoincrement, " +
                "tenLop text, " +
                "moTa text)";
        db.execSQL(sql);

        //Tạo bảng sinh viên
        sql = "CREATE TABLE sinhVien(" +
                "maSV integer primary key autoincrement, " +
                "tenSV text, " +
                "namsinh text," +
                "quequan text," +
                "namhoc text)";
        db.execSQL(sql);

        //Tạo sinhvien_lop
        sql = "CREATE TABLE SinhVien_Lop(" +
                "id integer primary key, " +
                "maLop integer," +
                "maSV integer," +
                "kyhoc text," +
                "sotinchi text)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
