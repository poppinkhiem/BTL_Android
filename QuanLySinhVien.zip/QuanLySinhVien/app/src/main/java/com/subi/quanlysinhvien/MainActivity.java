package com.subi.quanlysinhvien;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView sv, lop, tke;
        sv = findViewById(R.id.sinhvien);
        lop = findViewById(R.id.lop);
        tke = findViewById(R.id.loc2);

        sv.setOnClickListener(v -> {
            Intent intent = new Intent(this, SVActivity.class);
            startActivity(intent);
        });

        lop.setOnClickListener(v -> {
            Intent intent = new Intent(this, LopActivity.class);
            startActivity(intent);
        });

        tke.setOnClickListener(v -> {
            Intent intent = new Intent(this, LopActivity.class);
            startActivity(intent);
        });
    }
}