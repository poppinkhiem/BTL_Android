package com.subi.quanlysinhvien.add;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.subi.quanlysinhvien.LopActivity;
import com.subi.quanlysinhvien.R;
import com.subi.quanlysinhvien.database.DaoMaLop;
import com.subi.quanlysinhvien.model.Lop;

import java.util.ArrayList;

public class AddLop extends AppCompatActivity {
    EditText tenLop, moTa;
    Button btThemLop;
    DaoMaLop lopDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lop);

        tenLop = findViewById(R.id.edAddMaLop);
        moTa = findViewById(R.id.edtAddTenLop);
        btThemLop = findViewById(R.id.btnthemLop);

        btThemLop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lopDao = new DaoMaLop(AddLop.this);
                String ten = tenLop.getText().toString().toLowerCase();
                String mota = moTa.getText().toString();
                if (lopDao.them(new Lop(0, ten, mota))) {
                    startActivity(new Intent(AddLop.this, LopActivity.class));
                    finish();
                }
            }
        });
    }
}
